'use strict';
const fs      = require('fs');
const Browser = require('./browser.service');
const AuthSvc = require('./auth.service');
const { log } = require('../models/index');
const logger  = require('../utils/logger');
const { sleep, randInt } = require('../utils/delay');

const SEL = {
  composeBtn:    '[data-testid="SideNav_NewTweet_Button"]',
  tweetBox:      '[data-testid="tweetTextarea_0"]',
  tweetBtnInline:'[data-testid="tweetButtonInline"]',
  tweetBtn:      '[data-testid="tweetButton"]',
  fileInput:     '[data-testid="fileInput"]',
  likeBtn:       '[data-testid="like"]',
  unlikeBtn:     '[data-testid="unlike"]',
  retweetBtn:    '[data-testid="retweet"]',
  retweetConfirm:'[data-testid="retweetConfirm"]',
  replyBtn:      '[data-testid="reply"]',
  followBtn:     '[data-testid^="follow"]',
  primaryCol:    '[data-testid="primaryColumn"]',
  displayNameInput: 'input[name="displayName"]',
  bioInput:      'textarea[name="description"]',
  locationInput: 'input[name="location"]',
  websiteInput:  'input[name="url"]',
  saveProfileBtn:'[data-testid="Profile_Save_Button"]',
};

const ActionSvc = {

  // ── Tweet ─────────────────────────────────────────────────────
  async tweet(account, content) {
    if (!account.canDo('post')) throw new Error(`@${account.username}: daily post cap reached`);

    // Force fresh session — re-login if tokens expired
    await AuthSvc.ensureSession(account);
    const page = await Browser.getPage(account);
    const t0   = Date.now();

    try {
      await page.goto('https://x.com/home', { waitUntil: 'domcontentloaded', timeout: 35_000 });
      await sleep(2500, 3500);

      // Confirm we're actually on the home feed (not login page)
      const currentUrl = page.url();
      if (currentUrl.includes('/login') || currentUrl.includes('/i/flow')) {
        throw new Error(`Session expired mid-action for @${account.username} — re-login required`);
      }

      // Wait for compose button with longer timeout
      const composeLocator = page.locator(SEL.composeBtn);
      await composeLocator.waitFor({ state: 'visible', timeout: 25_000 }).catch(async () => {
        const url2 = page.url();
        throw new Error(`Compose button not found — possibly not logged in. URL: ${url2}`);
      });

      await composeLocator.click();
      await sleep(1200, 2000);

      // Tweet text area — use Locator API throughout
      const box = page.locator(SEL.tweetBox).first();
      await box.waitFor({ state: 'visible', timeout: 15_000 });
      await box.click();
      await sleep(500, 800);

      // Clear any existing text
      await page.keyboard.press('Control+a');
      await sleep(100, 200);
      await page.keyboard.press('Backspace');
      await sleep(300, 500);

      // Type text
      await this._humanType(page, content.text);
      await sleep(1200, 2000);

      // Verify text landed
      const boxText = await box.textContent().catch(() => '');
      logger.info(`[Action] Tweet compose: ${boxText.length} chars @${account.username}`);

      if (boxText.trim().length === 0) {
        throw new Error(`Text did not land in tweet box for @${account.username}`);
      }

      // Media
      if (content.mediaLocalPaths?.length) {
        const valid = content.mediaLocalPaths.filter(p => fs.existsSync(p)).slice(0, 4);
        if (valid.length) {
          const inp = await page.$(SEL.fileInput);
          if (inp) { await inp.setInputFiles(valid); await sleep(2500, 4000); }
        }
      }

      // Submit — use Locator for reliable enabled check
      // Try tweetButtonInline first (inside compose modal), fallback to tweetButton
      const submitLocator = page.locator(`${SEL.tweetBtnInline}, ${SEL.tweetBtn}`).first();

      // Wait up to 8s for button to become enabled
      let btnEnabled = false;
      for (let attempt = 0; attempt < 8; attempt++) {
        const count = await submitLocator.count().catch(() => 0);
        if (count > 0) {
          btnEnabled = await submitLocator.isEnabled().catch(() => false);
          if (btnEnabled) break;
        }
        await sleep(800, 1200);
      }

      if (!btnEnabled) {
        const boxContent = await box.textContent().catch(() => '');
        throw new Error(`Tweet button stayed disabled — box: "${boxContent.slice(0,60)}" (${boxContent.length} chars)`);
      }

      await submitLocator.click();
      await sleep(3000, 5000);

      const url     = page.url();
      const tweetId = url.match(/\/status\/(\d+)/)?.[1] || null;

      await account.bump('post');
      await Browser.persistSession(account);
      await log(account._id, 'publish', 'tweet_posted', 'success', { tweetId, ms: Date.now()-t0 });
      if (global.io) global.io.emit('action:done', { type:'tweet', account:account.username, tweetId });

      logger.info(`[Action] Tweet posted: @${account.username} ${tweetId||''} (${Date.now()-t0}ms)`);
      return { success:true, tweetId, tweetUrl: tweetId ? `https://x.com/${account.username}/status/${tweetId}` : null };

    } catch (e) {
      await log(account._id, 'publish', 'tweet_failed', 'failure', { error:e.message });
      logger.error(`[Action] Tweet failed @${account.username}: ${e.message}`);
      throw e;
    } finally {
      await page.close().catch(() => {});
    }
  },

  // ── Multi-account tweet ───────────────────────────────────────
  async tweetMulti(accounts, textOrFn, opts = {}) {
    const { delayBetweenMs = [8000, 20000], mediaLocalPaths = [] } = opts;
    const results = [];
    for (let i = 0; i < accounts.length; i++) {
      const account = accounts[i];
      const text    = typeof textOrFn === 'function' ? textOrFn(account) : textOrFn;
      try {
        const r = await this.tweet(account, { text, mediaLocalPaths });
        results.push({ username: account.username, ...r });
      } catch (e) {
        results.push({ username: account.username, success: false, error: e.message });
      }
      if (i < accounts.length - 1) await sleep(delayBetweenMs[0], delayBetweenMs[1]);
    }
    return results;
  },

  // ── Like ─────────────────────────────────────────────────────
  async like(account, tweetId) {
    if (!account.canDo('like')) throw new Error(`@${account.username}: daily like cap reached`);
    const page = await this._readyPage(account);
    try {
      await page.goto(`https://x.com/i/status/${tweetId}`, { waitUntil: 'domcontentloaded' });
      await sleep(1500, 2500);
      const alreadyLiked = await page.locator(SEL.unlikeBtn).count().catch(() => 0);
      if (alreadyLiked > 0) return { success:true, alreadyLiked:true };
      const likeBtn = await page.waitForSelector(SEL.likeBtn, { state:'visible', timeout:10_000 });
      await likeBtn.click();
      await sleep(800, 1500);
      await account.bump('like');
      await log(account._id, 'engage', 'like', 'success', { tweetId });
      return { success:true };
    } catch (e) {
      await log(account._id, 'engage', 'like_failed', 'failure', { tweetId, error:e.message });
      throw e;
    } finally { await page.close().catch(() => {}); }
  },

  // ── Retweet ───────────────────────────────────────────────────
  async retweet(account, tweetId) {
    if (!account.canDo('repost')) throw new Error(`@${account.username}: daily retweet cap reached`);
    const page = await this._readyPage(account);
    try {
      await page.goto(`https://x.com/i/status/${tweetId}`, { waitUntil: 'domcontentloaded' });
      await sleep(1500, 2500);
      await page.click(SEL.retweetBtn);
      await sleep(700, 1200);
      await page.click(SEL.retweetConfirm);
      await sleep(1000, 1800);
      await account.bump('repost');
      await log(account._id, 'engage', 'retweet', 'success', { tweetId });
      return { success:true };
    } catch (e) {
      await log(account._id, 'engage', 'retweet_failed', 'failure', { tweetId, error:e.message });
      throw e;
    } finally { await page.close().catch(() => {}); }
  },

  // ── Reply ─────────────────────────────────────────────────────
  async reply(account, tweetId, text) {
    if (!account.canDo('reply')) throw new Error(`@${account.username}: daily reply cap reached`);
    const page = await this._readyPage(account);
    try {
      await page.goto(`https://x.com/i/status/${tweetId}`, { waitUntil: 'domcontentloaded' });
      await sleep(2000, 3000);
      await page.click(SEL.replyBtn);
      await sleep(800, 1400);
      const replyBox = page.locator(SEL.tweetBox);
      await replyBox.waitFor({ state:'visible', timeout:10_000 });
      await replyBox.click();
      await sleep(300, 500);
      await this._humanType(page, text);
      await sleep(800, 1400);
      const btn = await page.$(SEL.tweetBtnInline) || await page.$(SEL.tweetBtn);
      if (btn && await btn.isEnabled().catch(()=>false)) { await btn.click(); await sleep(2000,3000); }
      await account.bump('reply');
      await log(account._id, 'engage', 'reply', 'success', { tweetId });
      return { success:true };
    } catch (e) {
      await log(account._id, 'engage', 'reply_failed', 'failure', { tweetId, error:e.message });
      throw e;
    } finally { await page.close().catch(() => {}); }
  },

  // ── Follow ────────────────────────────────────────────────────
  async follow(account, targetHandle) {
    if (!account.canDo('follow')) throw new Error(`@${account.username}: daily follow cap reached`);
    const page = await this._readyPage(account);
    try {
      await page.goto(`https://x.com/${targetHandle.replace('@','')}`, { waitUntil:'domcontentloaded' });
      await sleep(1500, 2500);
      const btn = await page.locator(SEL.followBtn).first();
      if (!btn) throw new Error('Follow button not found');
      const txt = (await btn.innerText().catch(()=>'')).toLowerCase();
      if (txt.includes('following') || txt.includes('unfollow')) return { success:true, alreadyFollowing:true };
      await btn.click();
      await sleep(800, 1500);
      await account.bump('follow');
      await log(account._id, 'engage', 'follow', 'success', { target:targetHandle });
      return { success:true };
    } catch (e) {
      await log(account._id, 'engage', 'follow_failed', 'failure', { target:targetHandle, error:e.message });
      throw e;
    } finally { await page.close().catch(() => {}); }
  },

  // ── Engagement campaign ───────────────────────────────────────
  async engageTweet(accounts, tweetId, actions, opts = {}) {
    const { replyTexts = [], delayBetweenMs = [5000, 15000] } = opts;
    const results = [];
    let replyIdx  = 0;
    for (let i = 0; i < accounts.length; i++) {
      const account = accounts[i];
      const r       = { username: account.username, tweetId, actions: {} };
      for (const action of actions) {
        try {
          if      (action === 'like')    r.actions.like    = await this.like(account, tweetId);
          else if (action === 'retweet') r.actions.retweet = await this.retweet(account, tweetId);
          else if (action === 'reply' && replyTexts.length) {
            r.actions.reply = await this.reply(account, tweetId, replyTexts[replyIdx++ % replyTexts.length]);
          }
          await sleep(2000, 5000);
        } catch (e) {
          r.actions[action] = { success:false, error:e.message };
          logger.warn(`[Action] engageTweet ${action} @${account.username}: ${e.message}`);
        }
      }
      results.push(r);
      if (i < accounts.length - 1) await sleep(delayBetweenMs[0], delayBetweenMs[1]);
    }
    return results;
  },

  // ── Search ────────────────────────────────────────────────────
  async search(account, keyword, maxResults = 20) {
    const page    = await this._readyPage(account);
    const results = [];
    try {
      await page.goto(`https://x.com/search?q=${encodeURIComponent(keyword)}&f=live`, { waitUntil:'domcontentloaded' });
      await sleep(2000, 3500);
      for (let i=0; i<3; i++) { await page.evaluate(()=>window.scrollBy(0,800)); await sleep(1200,2000); }
      const cards = await page.$$('[data-testid="tweet"]');
      for (const card of cards.slice(0, maxResults)) {
        try {
          const text   = await card.$eval('[data-testid="tweetText"]', e=>e.innerText).catch(()=>'');
          const link   = await card.$eval('a[href*="/status/"]', e=>e.href).catch(()=>'');
          const author = await card.$eval('[data-testid="User-Name"]', e=>e.innerText.split('\n')[0]).catch(()=>'');
          const id     = link.match(/\/status\/(\d+)/)?.[1];
          if (id && text) results.push({ id, text:text.slice(0,280), author, link });
        } catch {}
      }
      return results;
    } finally { await page.close().catch(()=>{}); }
  },

  // ── Update profile ────────────────────────────────────────────
  async updateProfile(account, updates = {}) {
    const page = await this._readyPage(account);
    try {
      await page.goto('https://x.com/settings/profile', { waitUntil:'domcontentloaded', timeout:25_000 });
      await sleep(1500, 2500);
      if (updates.displayName !== undefined) {
        const inp = await page.$(SEL.displayNameInput);
        if (inp) { await inp.click({ clickCount: 3 }); await sleep(150,250); await page.keyboard.press('Backspace'); await this._humanType(page, updates.displayName); await sleep(400,700); }
      }
      if (updates.bio !== undefined) {
        const bioEl = await page.$(SEL.bioInput);
        if (bioEl) { await bioEl.click({ clickCount: 3 }); await sleep(150,250); await page.keyboard.press('Backspace'); await this._humanType(page, updates.bio); await sleep(400,700); }
      }
      if (updates.location !== undefined) { await page.fill(SEL.locationInput, updates.location); await sleep(300,600); }
      if (updates.website  !== undefined) { await page.fill(SEL.websiteInput,  updates.website);  await sleep(300,600); }
      const saveBtn = await page.$(SEL.saveProfileBtn);
      if (!saveBtn) throw new Error('Save profile button not found');
      await saveBtn.click();
      await sleep(2000, 3000);
      await Browser.persistSession(account);
      await log(account._id, 'profile', 'profile_updated', 'success', { fields: Object.keys(updates) });
      return { success:true, updated:Object.keys(updates) };
    } catch (e) {
      await log(account._id, 'profile', 'profile_update_failed', 'failure', { error:e.message });
      throw e;
    } finally { await page.close().catch(()=>{}); }
  },

  // ── Sync profile stats ────────────────────────────────────────
  async syncProfile(account) {
    const page = await this._readyPage(account);
    try {
      await page.goto(`https://x.com/${account.username}`, { waitUntil:'domcontentloaded' });
      await sleep(1500, 2500);
      const parseCount = s => {
        if (!s) return 0;
        const n = s.replace(/,/g,'').trim();
        if (n.endsWith('K')) return Math.round(parseFloat(n)*1000);
        if (n.endsWith('M')) return Math.round(parseFloat(n)*1_000_000);
        return parseInt(n,10)||0;
      };
      const [name,bio,followers,following] = await Promise.all([
        page.$eval('[data-testid="UserName"] span',          e=>e.textContent).catch(()=>null),
        page.$eval('[data-testid="UserDescription"]',        e=>e.textContent).catch(()=>null),
        page.$eval('a[href$="/verified_followers"] span',    e=>e.textContent).catch(()=>null),
        page.$eval('a[href$="/following"] span',             e=>e.textContent).catch(()=>null),
      ]);
      account.profile = {
        displayName:    name?.trim()     || account.username,
        bio:            bio?.trim()      || '',
        followersCount: parseCount(followers),
        followingCount: parseCount(following),
        lastSyncedAt:   new Date(),
      };
      await account.save();
      return account.profile;
    } finally { await page.close().catch(()=>{}); }
  },

  // ── Helpers ───────────────────────────────────────────────────
  async _readyPage(account) {
    await AuthSvc.ensureSession(account);
    return Browser.getPage(account);
  },

  async _humanType(page, text) {
    for (const ch of String(text)) {
      await page.keyboard.type(ch, { delay: randInt(55, 130) });
    }
  },
};

module.exports = ActionSvc;
