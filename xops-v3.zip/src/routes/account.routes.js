'use strict';
const router = require('express').Router();
const ctrl   = require('../controllers/account.controller');
const { authMiddleware } = require('../middleware/index');
router.use(authMiddleware);

// ── Static routes أولاً (قبل /:id) ─────────────────────────
router.get   ('/',                     ctrl.list);
router.get   ('/stats',                ctrl.stats);
router.post  ('/',                     ctrl.create);
router.post  ('/bulk-import',          ctrl.bulkImport);
router.post  ('/bulk-check',           ctrl.bulkCheck);
router.post  ('/bulk-sync-profiles',   ctrl.bulkSyncProfiles);
router.post  ('/bulk-update-profiles', ctrl.bulkUpdateProfiles);

const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
router.post  ('/upload-images', upload.fields([{ name:'avatars', maxCount:50 }, { name:'banners', maxCount:50 }]), ctrl.uploadImages);

// ── Dynamic routes /:id بعدها ───────────────────────────────
router.get   ('/:id',                  ctrl.get);
router.patch ('/:id',                  ctrl.update);
router.patch ('/:id/credentials',      ctrl.updateCredentials);
router.delete('/:id',                  ctrl.remove);
router.post  ('/:id/check',            ctrl.checkSession);
router.post  ('/:id/login',            ctrl.login);
router.post  ('/:id/sync-profile',     ctrl.syncProfile);
router.post  ('/:id/update-profile',   ctrl.updateProfile);
router.post  ('/:id/suggest-bio',      ctrl.suggestBio);

module.exports = router;